/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package filesss.main;
/**
 *
 * @author ralph
 */
public class Main {

    public static void main(String[] args) {
        MyTime time = new MyTime(11, 50, 40, true);
        
        //True PM, False AM
        
        
        
        if(time.isMeridian()){
            System.out.printf("Time is %02d:%02d:%02d PM\n", time.getHours(),time.getMinutes(), time.getSeconds());
        } else {
            System.out.printf("Time is %02d:%02d:%02d AM\n", time.getHours(),time.getMinutes(), time.getSeconds());
        }
        
        time.advanceTime(10);
        time.tickBySecond();
        time.tickByMinute();
        time.tickByHour();
        time.displayTime12();
//        time.displayTime24();

    }
}
